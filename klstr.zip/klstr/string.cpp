#include<iostream.h>
#include<string.h>

#include"string.h"

ostream &operator<<(ostream &out, String &par)
{
	return out << par.ptr;
}

String::String(char *str) 
{        
	String ptr = new char [strlen(str)];

	String::len=strlen(str);
    strcpy(String::ptr, str);
}

String::String(const string &par) 
{
	ptr=new char [strlen(par.ptr)];
	strcpy(ptr, par.ptr);
}

String::~String(void)
{
	delete [] ptr;
}