/* 

		PBO Projekt 1 
		(C)2000 Pawe� Sa�kiewicz

		Implementacja klasy string do pracy na ci�gach znakowych

*/

#include<iostream.h>
#include<string.h>

class String {

	int len;    
	char *ptr;

public:    

	String(char * =NULL);
	String(const string &par);
		
	~String(void);

	friend ostream &operator<<(ostream(&out, String &par);
};
