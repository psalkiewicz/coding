
#include<iostream.h>

#include"string.h"

int main(void)
{
	String s1("Hello"),
	       s2(s1),
		   s3=s2;

	cout << s1 << endl;
	cout << s2 << endl;
	return 0;
}